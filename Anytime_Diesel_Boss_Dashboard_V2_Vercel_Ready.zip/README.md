# Anytime Diesel Boss Dashboard V2

This version fixes the Google Sheets connection problem in the original dashboard.

## Why V2 is different
The old dashboard used browser JavaScript:
`fetch(GooglePublishedCSVURL)`

Google's published CSV endpoint can redirect, and browser-side fetching can fail because of redirect/CORS behavior.

V2 uses:
Browser -> Vercel `/api/sheets` -> Google Sheets CSV -> Dashboard

The Vercel function only accepts `docs.google.com` URLs and follows Google's redirects server-side.

## Deploy
Upload this folder to a new Vercel project, or replace the files in your existing project.

## Google Sheets
Use only the `Boss_Publish` tab as the published CSV source.
Required columns:
company, sector, value, stage, probability, owner, month

Keep `value` and `probability` numeric in the published sheet:
850000
70

Do not publish phone numbers, personal emails, private notes, or sensitive customer data.

## Current Google CSV
You can paste your published CSV URL in Data Setup:
https://docs.google.com/spreadsheets/d/e/2PACX-1vQSg4Wwyn0VlanOxRrWFL8hplD-WL0vxHKLNeU1o1mOoRkwHjNPH4ndE9Y29z4OBg/pub?gid=1079011675&single=true&output=csv
